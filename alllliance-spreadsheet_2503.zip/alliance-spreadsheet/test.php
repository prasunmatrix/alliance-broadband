<?php
print_r('a');